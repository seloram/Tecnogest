package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.List;
import java.util.Optional;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Role;

public interface RoleService {
    
    List<Role> findRoles();

    Optional<Role> findById(Long id);

    Role save(Role role);

    void remove(Long id);
}
