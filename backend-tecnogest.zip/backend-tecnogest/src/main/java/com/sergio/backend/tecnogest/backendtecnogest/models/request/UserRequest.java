package com.sergio.backend.tecnogest.backendtecnogest.models.request;

import java.util.List;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Role;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public class UserRequest{

    @NotBlank(message = "Username cannot be blank")
    @Size(min = 2, max = 8, message = "must be between 2 and 8 characters long!!!")
    @Column(unique = true)
    private String username;

    @NotEmpty(message = "The email cannot be empty")
    @Email(message = "The email is not correct!!!")
    @Column(unique = true)
    private String email;

    private List<Role> roles;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    

}
