package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Category;

public interface CategoryService {

    Optional<Category> getCategoryById(Long id);
    
    String getNameByProductId(Long id);

    List<Category> findCategories();

    Page<Category> findCategoriesPage(Pageable pageable);
    
}
