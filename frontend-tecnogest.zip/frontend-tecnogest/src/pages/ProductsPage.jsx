import { NavLink, Navigate, Route, Routes, useNavigate, useParams } from "react-router-dom"
import { useProducts } from "../hooks/useProducts"
import { useEffect, useReducer, useState } from "react"
import { ProductsList } from "../component/ProductsList"
import { Paginator } from "../component/Paginator"
import { CartView } from "../component/CartView"
import { useItemsCart } from "../hooks/useItemsCart"

export const ProductsPage = ({ handlerAddProductCart }) => {
    const navigate = useNavigate();
    //const [cartItems, setCartItems] = useState(initialCartItems);
    const {
        products,
        paginator,
        getProducts,
    } = useProducts();
    const { page } = useParams();
    useEffect(() => {
        getProducts(page);
    }, [, page]);
    //const {cartItems, handlerAddProductCart, handlerDeleteProductCart} = useItemsCart();
    return (
        <>
            <div className="container m-y4">
                <div className="row">
                    <div className="col">
                        {products.length === 0 ?
                            <>
                                <div className="alert alert-warning">
                                    There are no products
                                </div>
                                <NavLink
                                    className={'btn btn-secondary btn-sm'}
                                    to={'/products/page/0'}
                                >Back to list
                                </NavLink>
                            </>
                            :
                            <>
                                <ProductsList handler={
                                    product => handlerAddProductCart(product)
                                } />
                                <Paginator url="/products/page" paginator={paginator} />
                                {/* <Routes>
                                    <Route path="cart" element={(cartItems?.length <= 0 ?
                                     <div className="alert alert-warning">Cart is empty!!!</div>:
                                    <div className="my-4 w-50">
                                        <CartView
                                            handlerDelete={handlerDeleteProductCart}
                                            items={cartItems}
                                        />
                                    </div>
                                )} />
                                </Routes> */}
                            </>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}