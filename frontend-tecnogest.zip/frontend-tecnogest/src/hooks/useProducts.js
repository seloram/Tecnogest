import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from "react-router-dom";
import {
    initialProductForm,
    loadingProducts,
    loadingError,
    addProduct,
    updateProduct,
    removeProduct,
    eraseErrors,
    clearForm
} from "../store/slices/products/productsSlice";
import { useAuth } from "../auth/hooks/useAuth";
import { findAllPagesProducts, save, update, remove } from "../services/productService";
import Swal from "sweetalert2";

export const useProducts = () => {

    const { products, errors, paginator, productSelected } = useSelector(state => state.products);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { login, handlerLogout } = useAuth();
    let productos = [];

    const getProducts = async (page = 0) => {

        try {
            const result = await findAllPagesProducts(page);
            dispatch(loadingProducts(result.data));
            productos = result.data.content;
        } catch (error) {
            if (error.response?.status == 401) {
                handlerLogout();
            }
        }
        return productos;

    }

    const handlerAddProduct = async (productForm, action) => {

        if (!login.isAdmin) return;
        let response;

        try {

            if (action == 'new') {
                response = await save(productForm);
                dispatch(addProduct(response.data));
            } else {
                response = await update(productForm);
                dispatch(updateProduct(response.data));
            }

            Swal.fire(
                (productForm.id == 0) ?
                    'Product created!!!' : 'Product updated!!!',
                (productForm.id == 0) ?
                    'The product has been created!!!' : 'The product has been updated',
                'success'
            );

            navigate('/products');
        } catch (error) {
            if (error.response && error.response.status == 400) {

                dispatch(loadingError({imageSize: 'The image is to big'}));
                // Swal.fire({
                //     title: 'Data Too Long!!!',
                //     confirmButtonText: 'Ok',
                //     text: error.productname
                // }).then((result) => {
                //     /* Read more about isConfirmed, isDenied below */
                //     // if (result.isConfirmed) {
                //     //     dispatch(restart(productSelected, errors));
                //     // }
                // })

            } else if (error.response && error.response.status == 403 &&
                error.response.data?.includes('constraint')) {

                if (error.response.data?.includes('UK_productName')) {
                    //dispatch(loadingError({ productname: 'The productname already exists!!!', error: true }));

                   Swal.fire({
                       title: 'Product already exits!!!',
                       confirmButtonText: 'Ok',
                       text: error.productname
                   }).then((result) => {
                       /* Read more about isConfirmed, isDenied below */
                       if (result.isConfirmed) {
                           dispatch(restart(productSelected, errors));
                       }
                   })
                }

                if (error.response.data?.includes('UK_product_name')) {
                    dispatch(loadingError({ productname: 'The product already exists!!!' }));
                }


            } else if (error.response?.status == 401) {
                handlerLogout();
            } else {
                throw error;
            }
        }

    }

    const handlerRemoveProduct = (id) => {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    await remove(id);
                    dispatch(removeProduct(id));
                    Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    )
                } catch (error) {
                    if (error.response?.status == 401) {
                        handlerLogout();
                    }
                }
            }
        })
    }

    const handlerCloseForm = () => {
        dispatch(loadingError({}));
    }

    const restart = (productForm, errors) => {
        dispatch(eraseErrors(errors));
        dispatch(clearForm(productForm));
    }

    return {
        products,
        errors,
        paginator,
        initialProductForm,
        eraseErrors,
        clearForm,
        handlerCloseForm,
        restart,
        getProducts,
        handlerRemoveProduct,
        handlerAddProduct,
    }
}