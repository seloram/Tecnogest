import React, { Children, createRef, useEffect, useRef, useState } from "react";
import Form from 'react-bootstrap/Form';
import { useUsers } from "../hooks/useUsers";
import { Button, Col, InputGroup, ListGroup, Row } from "react-bootstrap";
import CloseButton from 'react-bootstrap/CloseButton';
import { red } from "@mui/material/colors";
import { useRoles } from "../hooks/useRoles";
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import Dropdown from 'react-bootstrap/Dropdown';
import { Box, Checkbox, Chip, FormControl, FormHelperText, InputLabel, ListItemText, MenuItem, Select } from "@mui/material";
import * as formik from 'formik';
import * as yup from 'yup';
import { json } from "react-router-dom";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";
import { eraseErrors } from "../store/slices/users/usersSlice";
export const UserForm = ({ userSelected, handlerCloseForm, rolesDB, errorsUser }) => {
    //const { errors } = useUsers();
    const { errors } = useSelector(state => state.users);

    
    const { initialUserForm, handlerAddUser } = useUsers();
    const [chosenRole, setChosenRole] = useState();
    const [userForm, setUserForm] = useState(initialUserForm);
    if(errors.usernameForm){
            
        Swal.fire({
            title: 'Something happend',
            confirmButtonText: 'Ok',
            text: errors.usernameForm
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                setUserForm(initialUserForm);
                dispatch(eraseErrors());
            }
        })
    }
    if(errors.emailForm){
        Swal.fire({
            title: 'Something happend',
            confirmButtonText: 'Ok',
            text: errors.emailForm
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                setUserForm(initialUserForm);
                dispatch(eraseErrors());
            }
        })
        
    }
    const dispatch = useDispatch();
    useEffect(() => {

    })
    console.log(errors);
    let typeForm = '';
    if (userSelected.id == 0)
        typeForm = 'new'
    else
        typeForm = 'update'

    const { Formik } = formik;

    const schema = yup.object().shape({
        yup_email: yup.string().email('Invalid email').required('Required'),
        yup_password: yup.string().required('Required'),
        yup_username: yup.string()
            .max(10, 'too long')
            .required('Required'),
        yup_roles: yup.array().min(1, 'You must choose one Role').required('Required'),
        // yup_city: yup.string().required(),
    });

    const schemaUpdate = yup.object().shape({
        yup_email: yup.string().email('Invalid email').required('Required'),
        //     yup_password: yup.string().notRequired(),
        yup_username: yup.string()
            .max(10, 'too long')
            .required('Required'),
        yup_roles: yup.array().min(1, 'You must choose one Role').required('Required'),
        // yup_city: yup.string().required(),
    });

    const list = document.getElementById('listRole');
    
    const [checked, setChecked] = useState(userForm.admin);
    let { id, username, password, email, admin, roles } = userForm;
    const [userRoles, setUserRoles] = useState([]);
    let rolesArray = [];
    var lista = document.getElementById("listaRoles");
    // const [rolesArray, setRolesArray] = useState([]);


    useEffect(() => {
        setUserForm({
            ...userSelected,
            password: '',
        });
    }, [userSelected]);


    const onInputChange = ({ target }) => {
        // console.log(target.value);
        const { name, value } = target;
        setUserForm({
            ...userForm,
            [name]: value,
        })
        // if (target.id) {
        //     selectUser(target);
        // }
    }

    const selected = (event) => {
        setChosenRole(event);
        userForm.roles.push(Object.preventExtensions(event));
    }

    const onCheckboxChange = () => {
        setChecked(!checked);
        setUserForm({
            ...userForm,
            admin: checked,
        });
    }
    useEffect(() => {

    })

    const [formValidity, setFormValidity] = useState(false);
    const [validated, setValidated] = useState(false);
    const onSubmit = async (event, isValid, touched) => {
        const form = event.currentTarget;
        const listRole = document.getElementById("listRole");

        // const form = document.getElementById('idForm');

        if (isValid == true) {
            if ((typeForm == 'update' && personName.length > 0) || (typeForm == 'new'))
                userForm.roles = personName;
        }

        // if (form.checkValidity() !== false) {
        //     event.preventDefault();
        //     if (list?.children > 0) {
        //         for (let r of list.children) {
        //             const roles = [...userRoles, { id: r.id, name: r.value }]
        //         }
        //         setUserRoles(roles)
        //     }
        // } else {
        //     //userForm.roles = personName.length == 0 ? roles : personName;
        //     handlerAddUser(userForm);
        // }
        // if (form.checkValidity() == true && listRole.getAttribute("hidden") == "true") {

        if (isValid == true) {
            //userForm.roles = Object.preventExtensions(rolesArray);
            await handlerAddUser(userForm);
        }
        //setUserForm(initialUserForm);

        setPersonName([]);


    }

    const onCloseForm = () => {
        handlerCloseForm();
        setUserForm(initialUserForm);
    }

    let idSelect = document.getElementById('multiple-chip');
    let menuItem = createRef();
    let listGroupItem = document.createElement('ListGroup.Item');

    const selectUser = (event) => {

        const idSelected = document.getElementById('1');
        let idUser = document.getElementById('2');
        const list = document.getElementById('listRoles');
        list.appendChild(listGroupItem);
        let lista = [...list.children];
        let lista_id = lista.find((e) => e.id == "id_" + event.selectedOptions[0].id);
        if (lista_id !== undefined) {
            document.getElementById(lista_id.id).parentNode.removeChild(lista_id);
        } else {
            listGroupItem.innerText = event.selectedOptions[0].value;
            listGroupItem.value = event.selectedOptions[0].value;
            listGroupItem.id = "id_" + event.selectedOptions[0].id;
        }
    }
    const [chosenRoles, setChosenRoles] = useState([]);
    const populateList = (event) => {

        const role = JSON.parse(event);
        // setChosenRole(chosenRole,role);
        let lista = list.children;
        let erased = false;

        if (list.children.length > 0) {
            for (let i of list.children) {
                if (i.id == role.id) {
                    list.removeChild(i);
                    erased = true;
                    for (let j of list.children) {
                        if (j.id == 2) {
                            list.removeChild(j);
                            // setChosenRole(chosenRole,chosenRole.remove(j))
                        }
                    }
                }
            }
        }

        if (erased == false) {
            let listGroupItem = document.createElement('ListGroup.Item');
            listGroupItem.innerText = role.name;
            listGroupItem.value = role.name;
            listGroupItem.id = role.id;
            list.appendChild(listGroupItem);
        }

    }

    // if (list.children.length == 0) {

    //     listGroupItem.innerText = role.name;
    //     listGroupItem.value = role.name;
    //     listGroupItem.id = role.id;
    //     list.appendChild(listGroupItem);

    // } else {

    //     for (let i of list.children){
    //         if(i.id==role.id){
    //             list.removeChild(i);
    //         }
    //     }}

    let selectRoles = document.getElementById('selectRoles');
    // const [personName, setPersonName] = useState([]);
    let arraySelected = [];

    // const handleChange = (event) => {
    //     const {
    //         target: { value },
    //     } = event;

    //     arraySelected.push(value[value.length - 1].name);

    //     setPersonName(
    //         typeof value === 'string' ? value.split(',') : value,
    //         // On autofill we get a stringified value.
    //         // typeof value[value.length -1].name === 'object' ? value.split(',') : value[value.length -1].name ,
    //         //typeof value[value.length - 1].name === 'string' ? arraySelected.split(',') : arraySelected.push(value[value.length - 1].name),
    //         //setPersonName([...personName, value[value.length - 1].name])
    //         //arraySelected.push(value[value.length - 1].name)
    //     );
    // };
    const [personName, setPersonName] = React.useState([]);

    const handleChangeSelect = (event) => {
        const {
            target: { value },
        } = event;
        setPersonName(
            // On autofill we get a stringified value.
            typeof value === 'string' ? value.split(',') : value,
        );
    };

    const selectedRole = (event) => {
        document.getElementById("listRole").hidden = true;
        const role = rolesDB.find(e => e.id == event);
        let roles = rolesArray.includes(role);

        if (roles) {
            rolesArray = rolesArray.filter(e => e.id !== role.id);
        } else {
            rolesArray.push(role);
        }

        let repeated = false;
        if (lista.children.length > 0) {
            for (var i = 0; i < lista.children.length; i++) {
                if (role.id == lista.children[i].id) {
                    lista.children[i].parentNode.removeChild(lista.children[i]);
                    repeated = true;
                }
            }
        }

        if (!repeated) {
            var li_role = document.createElement('li');
            li_role.innerHTML = role.name;
            li_role.id = role.id;
            lista.appendChild(li_role);
        } else
            repeated = false;
    }

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
        },
    };
    return (
        <Formik
            enableReinitialize
            validationSchema={typeForm === 'update' ? schemaUpdate : schema}
            // validationSchema={schema}
            onSubmit={values => { console.log(values); }}
            initialValues={typeForm == 'new' ? {
                yup_email: email,
                yup_password: password,
                yup_username: username,
                yup_roles: roles,
                // yup_city: rolesArray
            } :
                {
                    yup_email: email,
                    yup_username: username,
                    yup_roles: roles,
                }
            }
        >
            {({ values,
                errors,
                touched,
                handleChange,
                handleBlur,
                handleSubmit,
                resetForm,
                isValid,
                dirty,
                validateForm,
                isSubmitting }) => (
                <Form
                    id="idForm"
                    className="needs-validation"
                    noValidate
                    onSubmit={e => { handleSubmit(e); onSubmit(e, isValid, touched); console.log(errors);/* resetForm() */ }} >
                    <Form.Group as={Row} className="mb-3" >
                        <Form.Label column sm="4" >
                            User's details
                        </Form.Label>
                        <Col sm="4">
                            {
                                !handlerCloseForm
                                ||
                                <CloseButton
                                    onClick={() => onCloseForm()}>
                                </CloseButton>
                            }
                        </Col>
                    </Form.Group>

                    <Form.Group as={Row} className="mb-5" controlId="formPlaintextEmail">
                        <Form.Label column sm="2">
                            Email
                        </Form.Label>
                        <Col sm={!handlerCloseForm ? 4 : 6}>
                            <InputGroup hasValidation>
                                <Form.Control
                                    required
                                    type="email"
                                    name="yup_email"
                                    value={values.yup_email}
                                    onChange={e => { handleChange(e); onInputChange(e) }}
                                    placeholder={'Email'}
                                    isInvalid={touched.yup_email && errors.yup_email}
                                />
                                <Form.Control.Feedback tooltip type="invalid">
                                    {errors.yup_email}
                                </Form.Control.Feedback>

                            </InputGroup>
                        </Col>
                        <Col sm={4}>
                            <Form.Control.Feedback tooltip type="invalid">
                                {errors.yup_email}
                            </Form.Control.Feedback>
                        </Col>
                    </Form.Group>

                    {id > 0 ||
                        <Form.Group as={Row} className="mb-5" controlId="formPlaintextPassword">
                            <Form.Label column sm="2">
                                Password
                            </Form.Label>
                            <Col sm="4">
                                <InputGroup hasValidation>
                                    <Form.Control
                                        required={typeForm == 'update' ? false : true}
                                        type="password"
                                        name="yup_password"
                                        value={values.yup_password}
                                        onChange={e => { handleChange(e); onInputChange(e) }}
                                        placeholder={"Password"}
                                        isInvalid={!!touched.yup_password && !!errors.yup_password}
                                    />
                                    <Form.Control.Feedback tooltip type="invalid">
                                        {errors.yup_password}
                                    </Form.Control.Feedback>
                                </InputGroup>
                            </Col>
                        </Form.Group>
                    }

                    <Form.Group as={Row} className="mb-5" controlId="formPlaintextUsername">
                        <Form.Label column sm="2">
                            Username
                        </Form.Label>
                        <Col sm="4">
                            <InputGroup hasValidation>
                                <Form.Control
                                    required
                                    type="text"
                                    name="yup_username"
                                    value={values.yup_username}
                                    onChange={e => { handleChange(e); onInputChange(e) }}
                                    placeholder={"Username"}
                                    isInvalid={touched.yup_username && !!errors.yup_username}
                                />
                                <Form.Control.Feedback tooltip type="invalid">
                                    {errors.yup_username}
                                </Form.Control.Feedback>
                            </InputGroup>
                        </Col>
                    </Form.Group>

                    {/* <Form.Group as={Row} className="mb-5" controlId="formPlaintextRoles">
                        <Col sm="4">
                            <Dropdown
                                onSelect={e => selectedRole(e)}
                            >
                                <Dropdown.Toggle variant="success" id="dropdown-basic">
                                    Dropdown Button
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                    {rolesDB.map((role) => (
                                        <Dropdown.Item eventKey={role.id} >{role.name}</Dropdown.Item>
                                    ))}
                                </Dropdown.Menu>
                            </Dropdown>
                            <div
                                hidden
                                id="listRole"
                                style={{ backgroundColor: "rgba(220,76,100,.9)", color: "white" }}
                                className="alert alert-danger">You must choose a role!!!
                            </div>

                        </Col>
                        <Col sm="4">

                            <InputGroup hasValidation>


                            </InputGroup>
                        </Col>

                        <ul className="list-group" style={{ listStyle: "none" }} id="listaRoles">

                        </ul>
                    </Form.Group> */}

                    {/*
                    <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                        <Form.Label column sm="2">
                            Roles
                        </Form.Label>
                        <Col sm="4">
                            <select
                                aria-label="Default select example"
                                onChange={e => { selectedRole(e) }}
                            >
                                <option>Add a role</option>
                                {rolesDB.map((role) => (
                                    <option key={role.id} value={role}>
                                        {role.name}
                                    </option>
                                ))}

                            </select>
                            <Form.Control.Feedback tooltip type="invalid">
                                {errors.yup_roles}
                            </Form.Control.Feedback>

                        </Col>
                    </Form.Group> */}

                    <Form.Group
                        as={Row}
                        className="mb-3">
                        <Form.Label column sm="2">
                            Select Role
                        </Form.Label>
                        <Col sm={4}>
                            <InputGroup hasValidation>
                                <FormControl fullWidth>
                                    <InputLabel id="demo-multiple-name-label">Roles</InputLabel>

                                    <Select
                                        id="demo-multiple-checkbox"
                                        multiple
                                        required
                                        name="yup_roles"
                                        value={personName}
                                        onChange={e => {
                                            //values.yup_roles = e.target.value;
                                            handleChange(e);
                                            handleChangeSelect(e)
                                        }}
                                        renderValue={(selected) => personName.map(e => e.name) + '  '}
                                        MenuProps={MenuProps}
                                    >
                                        {rolesDB.map((role) => (
                                            <MenuItem key={role.id} value={role}>
                                                <Checkbox checked={personName.map(e => { return e.name; }).indexOf(role.name) > -1} />
                                                <ListItemText primary={role.name} />
                                            </MenuItem>
                                        ))}
                                    </Select>

                                    <div>{errors.yup_roles ?
                                        <div
                                            className="alert alert-danger"
                                            style={{ 'fontSize': '12px', 'backgroundColor': 'rgba(220,76,100,.9)', 'color': 'white' }}>
                                            {errors.yup_roles}
                                        </div> : null}
                                    </div>
                                    <Form.Control.Feedback tooltip type="invalid">
                                        {errors.yup_roles}
                                    </Form.Control.Feedback>
                                </FormControl>
                            </InputGroup>
                        </Col>

                        <Col sm={4}>
                            <ListGroup id="listRoles">
                            </ListGroup>
                        </Col>

                    </Form.Group>

                    <Form.Label
                        type="hidden"
                        name="id"
                        value={id}
                    />
                    {JSON.stringify({ dirty, isValid, touched, validateForm })}
                    <Button variant="primary" type="submit" >
                        {id > 0 ? 'Update' : 'Create'}
                    </Button>

                </Form>

            )
            }

            {/* <form onSubmit={onSubmit}>
                <input
                    className="form-control my-3 w-75"
                    placeholder="Username"
                    name="username"
                    value={username}
                    onChange={onInputChange}
                />
                <p className="text-danger">{errors?.username}</p>
                {id > 0 || <input
                    className="form-control my-3 w-75"
                    placeholder="Password"
                    type="password"
                    name="password"
                    value={password}
                    onChange={onInputChange}
                />}
                <p className="text-danger">{errors?.password}</p>

                <input
                    className="form-control my-3 w-75"
                    placeholder="Email"
                    name="email"
                    value={email}
                    onChange={onInputChange} />
                <p className="text-danger">{errors?.email}</p>

                <div className="my-3 form-check">
                    <input type="checkbox"
                        name="admin"
                        checked={admin}
                        className="form_check-input"
                        onChange={onCheckboxChange}
                    />
                    <label className="form-check-label mx-1">Admin</label>
                </div>

                <input
                    type="hidden"
                    name="id"
                    value={id}
                />
                <button
                    className="btn btn-primary"
                    type="submit">
                    {id > 0 ? 'Update' : 'Create'}
                </button>
                {
                    !handlerCloseForm || <button
                        type="button"
                        className="btn btn-primary mx-2"
                        onClick={() => onCloseForm()}>
                        Cerrar
                    </button>
                }
            </form> */}
        </Formik >
    )

}