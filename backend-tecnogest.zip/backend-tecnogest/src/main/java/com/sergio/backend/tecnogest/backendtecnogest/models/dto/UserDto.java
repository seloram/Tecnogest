package com.sergio.backend.tecnogest.backendtecnogest.models.dto;

import java.util.List;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Role;

public class UserDto {
    
    private Long id;
    private String username;
    private String email;
    private boolean admin;
    private List<Role> roles;
    
    public UserDto() {
    }
    
    public UserDto(Long id, String username, String email, boolean admin, List<Role> roles) {        
        this.id = id;
        this.username = username;
        this.email = email;
        this.admin = admin;
        this.roles = roles;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }  
    
    

}
