import { Navigate, Route, Routes, useParams } from "react-router-dom";
import { useProducts } from "../hooks/useProducts";
import { useEffect } from "react";
import { useItemsCart } from "../hooks/useItemsCart";
import { ProductsPage } from "../pages/ProductsPage";
import { Navbar } from "../component/layout/Navbar";
import { CartPage } from "../pages/CartPage";
import { CartView } from "../component/CartView";
import { calculateTotal, totalItems } from "../services/productService";
import { useSelector } from "react-redux";
import { AddProductPage } from "../pages/AddProductPage";
import { useCategories } from "../hooks/useCategories";

export const ProductRoutes = () => {
    const { isAdmin } = useSelector(state => state.auth);
    const { cartItems, handlerAddProductCart, handlerDeleteProductCart } = useItemsCart();
    const { categories, getCategories } = useCategories();
    const { page } = useParams();
    useEffect(() => {
        getCategories(page);
    }, [, page]);
    return (
        <>
            <Navbar quantity={totalItems(cartItems)} total={calculateTotal(cartItems)} />
            <Routes>

                <Route path="/*" element={
                    <ProductsPage handlerAddProductCart={handlerAddProductCart} />
                } />
                <Route path="/cart" element={(cartItems?.length <= 0 ?
                    <div className="alert alert-warning">Cart is empty!!!</div> :
                    <div className="my-4 w-50">
                        <CartView
                            handlerDelete={handlerDeleteProductCart}
                            items={cartItems}
                        />
                    </div>
                )} />
                {!isAdmin

                    ||
                    <>
                        <Route path="/update/:id" element={
                            <AddProductPage categories={categories} />
                        } />
                        <Route path="/addProduct" element={
                            <AddProductPage categories={categories} />
                        } />
                    </>
                }
                <Route path="/page/:page/*" element={
                    <ProductsPage handlerAddProductCart={handlerAddProductCart} />
                } />

            </Routes>
        </>
    )
}