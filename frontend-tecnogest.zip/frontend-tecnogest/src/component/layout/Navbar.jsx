import { NavLink } from "react-router-dom";
import { useAuth } from "../../auth/hooks/useAuth";
import { useItemsCart } from "../../hooks/useItemsCart";
import { useEffect, useState } from "react";
import { initialProductForm } from "../../store/slices/products/productsSlice";
import { Button } from "@mui/material";
import 'bootstrap/dist/css/bootstrap.min.css';

export const Navbar = ({ quantity, total, lPage }) => {

    const { login, handlerLogout } = useAuth();

    return (
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
                <NavLink className="nav-link mx-5" to="/"><h2>Tecnogest</h2> </NavLink>
                <button className="navbar-toggler"
                    type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNav" aria-controls="navbarNav"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">

                        <li className="nav-item mx-3">
                            <NavLink
                                className="nav-link"
                                to="/users"
                            >
                                <b>Users</b>
                            </NavLink>
                        </li>

                        {!login.isAdmin ||
                            <>
                                <li className="nav-item mx-3">
                                    <NavLink
                                        className="nav-link"
                                        to="/users/register"
                                    >
                                        <b>Register</b>
                                    </NavLink>
                                </li>
                                <li className="nav-item mx-3">
                                    <NavLink
                                        className="nav-link"
                                        to="/products/addProduct"
                                    >
                                        <b>Add product</b>
                                    </NavLink>
                                </li>
                            </>
                        }

                        <li className="nav-item mx-3">
                            <NavLink
                                className="nav-link"
                                to="/products"
                            >
                                <b>Products</b>
                            </NavLink>
                        </li>

                        <li className="nav-item mx-3">
                            <NavLink
                                className="nav-link"
                                to="/products/cart"
                            >
                                <div style={{ display: "flex" }}>
                                    <p style={{ marginRight: '12px' }}>
                                        <b>Cart</b> {quantity}</p>
                                    <b style={{ marginRight: '8px' }}>Total: </b>
                                    <p style={{ color: 'red', textDecoration: 'underline' }}> {total} €</p>
                                </div>

                            </NavLink>
                        </li>
                    </ul>
                </div>
                {lPage==true||<div className="collapse navbar-collapse justify-content-end" id="navbarNavLogout">
                    <span className="nav-item nav-link text-primary mx-3">
                        {login.user?.username}
                    </span>
                    <NavLink to={login.isAuth? "/products":"/login"} >
                        <Button
                           
                            variant="contained"
                            onClick={handlerLogout}
                            color="success"
                            className="btn-outline-success"
                        >
                            {login.isAuth ? 'Logout' : 'Login'}

                        </Button>
         
                
                    </NavLink>
                </div>}
                
            </div>
        </nav>
    );
}