import { useState } from "react";
import Swal from "sweetalert2";
import { useAuth } from "../hooks/useAuth";
import { Navbar } from "../../component/layout/Navbar";
import { useItemsCart } from "../../hooks/useItemsCart";
import { calculateTotal, totalItems } from "../../services/productService";
import { red } from "@mui/material/colors";

const initialLoginForm = {
    username: '',
    password: '',
}

export const LoginPage = () => {

    const { handlerLogin } = useAuth();
    const { cartItems } = useItemsCart();
    const [loginForm, setLoginForm] = useState(initialLoginForm);
    const { username, password } = loginForm;

    const onInputChange = ({ target }) => {
        const { name, value } = target;
        setLoginForm({
            ...loginForm,
            [name]: value,
        })
    }

    const onSubmit = (event) => {
        event.preventDefault();

        if (!username || !password) {
            Swal.fire("Error", "User or password are empty!!!", "error");
        }

        handlerLogin({ username, password });
        setLoginForm(initialLoginForm);
    }

    return (
        <>

            <Navbar lPage={true} quantity={totalItems(cartItems)} total={calculateTotal(cartItems)} />

            <div className="header shadow-lg p-3 mb-5 bg-body rounded"
                style={{ display: "flex", alignItems: "center", flexDirection: "column" }}>
                <img
                    className="logo"
                    style={{ width: 400, margin: 20 }}
                    src="src/images/tecnogest_image.jpg"
                    alt="" />
            </div>
            <div className="" style={{ fontSize: 20, marginLeft: 500, color: "red", marginBottom: 50 }}>Costumer Login</div>
            <form
                action=""
                className="container shadow rounded"
                style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    border: "1px outset black",
                    padding: "20px",
                    width: "45%"
                }}

                onSubmit={onSubmit}>

                <input
                    className="form-control my-3 w-50"
                    placeholder="Username"
                    name="username"
                    value={username}
                    style={{ textAlign: "center" }}
                    onChange={onInputChange}
                />

                <input
                    className="form-control my-3 w-50"
                    placeholder="Password"
                    type="password"
                    name="password"
                    style={{ textAlign: "center" }}
                    value={password}
                    onChange={onInputChange}
                />

                <button
                    id="loginbtn"
                    type="submit"
                    className="btn btn-primary position-relative start-0 left-0"
                >
                    Login
                </button>

            </form>

            <div className="footer" style={{ backgroundColor: "grey", height: "30px", marginTop: "200px", paddingTop: "200px" }}>

            </div>

        </>
    );
}