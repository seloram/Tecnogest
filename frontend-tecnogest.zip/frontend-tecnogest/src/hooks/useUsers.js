import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { findAll, findAllPages, remove, save, update } from "../services/userService";
import { useDispatch, useSelector } from "react-redux";
import {
    initialUserForm,
    addUser,
    loadingUsers,
    onCloseForm,
    onOpenForm,
    onUserSelectedForm,
    removeUser,
    updateUser,
    loadingError
} from "../store/slices/users/usersSlice";
import { useAuth } from "../auth/hooks/useAuth";

export const useUsers = () => {

    // const [users, dispatch] = useReducer(usersReducer, initialUsers);
    const { users, userSelected, visibleForm, errors, paginator } = useSelector(state => state.users);
    const dispatch = useDispatch();
    // const [userSelected, setUserSelected] = useState(initialUserForm);
    // const [visibleForm, setVisibleForm] = useState(false);

    // const [errors, setErrors] = useState(initialErrors);

    const navigate = useNavigate();

    const { login, handlerLogout } = useAuth();

    const getUsers = async (page = 0) => {

        try {
            const result = await findAllPages(page);
            dispatch(loadingUsers(result.data));

        } catch (error) {
            if (error.response?.status == 401) {
                handlerLogout();
            }
        }
    }

    const handlerAddUser = async (user) => {
        let newUser = {
            id:0,
            username:'',
            roles:[],
            email:''
        };
        newUser.id = user.id;
        newUser.email = user.yup_email||user.email;
        newUser.password = user.yup_password||user.password;
        newUser.roles = user.roles;
        newUser.username = user.yup_username||user.username;
        
        if (!login.isAdmin) return;
        let response;

        try {

            if (user.id === 0) {
                response = await save(newUser);
                dispatch(addUser(response.data));
            } else {
                response = await update(newUser);
                dispatch(updateUser(response.data));
            }

            Swal.fire(
                (user.id === 0) ?
                    'User created!!!'
                    : 'User updated',
                (user.id === 0) ?
                    'The user has been created'
                    : 'The user has been updated',
                'success'
            );
            
            handlerCloseForm();
            navigate('/users');
        } catch (error) {
            console.log(error);
            if (error.response && error.response.status == 400) {
                dispatch(loadingError(error.response.data));
            } else if (error.response && error.response.status == 403 &&
                error.response.data?.includes('constraint')) {

                if (error.response.data?.includes('UK_username')) {
                    console.log("error username" +  error.response.data);
                    dispatch(loadingError({ usernameForm: 'The username already exists!!!' }));
                    // Swal.fire({
                    //     title: 'Username already exits!!!',
                    //     confirmButtonText: 'Ok',
                    //     text: error.productname
                    // }).then((result) => {
                    //     /* Read more about isConfirmed, isDenied below */
                    //     if (result.isConfirmed) {
                           
                    //     }
                    // })
                }
                if (error.response.data?.includes('UK_email')) {
                    console.log("error email");
                    dispatch(loadingError({ emailForm: 'The email already exists!!!' }));
                    // Swal.fire({
                    //     title: 'Email already exits!!!',
                    //     confirmButtonText: 'Ok',
                    //     text: error.productname
                    // }).then((result) => {
                    //     /* Read more about isConfirmed, isDenied below */
                    //     if (result.isConfirmed) {
                           
                    //     }
                    // })
                }
            } else if (error.response?.status == 401) {
                handlerLogout();
            } else {
                dispatch(loadingError(error.response.status));
                dispatch(onCloseForm());
                throw error;
            }
        }
    }

    const handlerRemoveUser = (id) => {
        // console.log(id);

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    await remove(id);
                    dispatch(removeUser(id));
                    Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    )

                } catch (error) {
                    if (error.response?.status == 401) {
                        handlerLogout();
                    }
                }
            }
        });
    }

    const handlerUserSelectedForm = (user) => {
        // setVisibleForm(true);
        // setUserSelected({ ...user });
        dispatch(onUserSelectedForm({ ...user }));
    }

    const handlerOpenForm = () => {
        // setVisibleForm(true);
        dispatch(onOpenForm());
    }

    const handlerCloseForm = () => {
        // setVisibleForm(false);
        // setUserSelected(initialUserForm);
        dispatch(onCloseForm());
        dispatch(loadingError({}));
    }

    return {
        users,
        userSelected,
        initialUserForm,
        visibleForm,
        errors,
        paginator,
        handlerOpenForm,
        handlerCloseForm,
        handlerAddUser,
        handlerRemoveUser,
        handlerUserSelectedForm,
        getUsers,
    }
}