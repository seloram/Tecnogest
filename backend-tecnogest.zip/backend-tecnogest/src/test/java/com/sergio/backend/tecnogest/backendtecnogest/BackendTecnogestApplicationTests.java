package com.sergio.backend.tecnogest.backendtecnogest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTecnogestApplicationTests {

	@Test
	void contextLoads() {
	}

}
