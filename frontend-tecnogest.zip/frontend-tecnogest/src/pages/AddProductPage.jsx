import { useEffect, useState } from "react";
import { ProductForm } from "../component/ProductForm"
import { useProducts } from "../hooks/useProducts"
import { useParams } from "react-router-dom";
import { useCategories } from "../hooks/useCategories";


export const AddProductPage = ({categories}) => {

    const { products = [], initialProductForm } = useProducts();
    const [productSelected, setProductSelected] = useState(initialProductForm);
    const { id } = useParams();

    useEffect(() => {
        if (id) {
            const product = products.find(p => p.id == id) || initialProductForm;
            console.log(product['price']);
            setProductSelected(product);
        }
    }, [id])

    return (
        <div className="container my-4">

            <h4>{productSelected.id > 0 ? 'Product details' : 'Add product'} </h4>
            <div className="row">
                <div className="col">
                    <ProductForm categories={categories} productSelected={productSelected} />
                </div>
            </div>
        </div>
    )
}