package com.sergio.backend.tecnogest.backendtecnogest.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

import org.apache.commons.io.FilenameUtils;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.boot.json.JsonParser;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.ByteArrayResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Category;
import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Product;
import com.sergio.backend.tecnogest.backendtecnogest.services.CategoryService;
import com.sergio.backend.tecnogest.backendtecnogest.services.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/products")
@CrossOrigin(originPatterns = "*")
public class ProductController {
    private static String imageDirectory = System.getProperty("user.dir") + "/images/";
    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public List<Product> list() {
        return productService.findProducts();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> show(@PathVariable Long id) {
        Optional<Product> p = productService.findById(id);

        if (p.isPresent()) {
            return ResponseEntity.ok(p.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/page/{page}")
    public Page<Product> list(@PathVariable Integer page) {
        Pageable pageable = PageRequest.of(page, 3);
        return productService.findAll(pageable);
    };

    @GetMapping("/category/{id}")
    public String categoryName(@PathVariable Long id) {
        return categoryService.getNameByProductId(id);
    }

    // @PostMapping("/addProduct")
    // public ResponseEntity<?> createWithFoto(@Valid Product product,
    // BindingResult result,
    // @RequestParam("imageFile") MultipartFile image,
    // @RequestParam("idCategory") Long idCategory,
    // @RequestParam("name") String name) {

    // Optional<Category> cat = categoryService.getCategoryById(idCategory);
    // Category category = new Category(cat.get().getId(), cat.get().getName());
    // Logger logger = Logger.getLogger(
    // ProductController.class.getName());
    // logger.info(product.toString());

    // // Category cat = new Category(Long.parseLong(category.getBytes("id")),
    // // category.getBytes("name"));
    // ObjectMapper objectMapper = new ObjectMapper();

    // // Category cat2 = new Category();
    // // cat2.setId((long) 4);
    // // cat2.setName("Graphic Card");
    // // try {
    // // cat = objectMapper.readValue(category, Category.class);
    // // System.console().writer().write(cat.getName());
    // // System.console().writer().write(cat.getId().toString());

    // // product.setCategory(cat2);
    // // } catch (JsonMappingException e) {
    // // // TODO Auto-generated catch block
    // // e.printStackTrace();
    // // } catch (JsonProcessingException e) {
    // // // TODO Auto-generated catch block
    // // e.printStackTrace();
    // // }
    // product.setCategory(category);
    // Long key = new Date().getTime();

    // if (result.hasErrors()) {
    // return validation(result);
    // }

    // makeDirectoryIfNotExist(imageDirectory);
    // Path fileNamePath = Paths.get(imageDirectory,
    // key.toString().concat(".").concat(FilenameUtils.getExtension(image.getOriginalFilename())));

    // try {
    // Files.write(fileNamePath, image.getBytes());
    // product.setImage(image.getBytes());
    // return
    // ResponseEntity.status(HttpStatus.CREATED).body(productService.save(product));
    // } catch (IOException ex) {
    // return new ResponseEntity<>("Image is not uploaded", HttpStatus.BAD_REQUEST);
    // }

    // }

    /* pruebas */
    @PostMapping(value = "/addProduct")
    public ResponseEntity<?> createWithFoto(@Valid @RequestBody Product product,
            BindingResult result) {

        Product pro = new Product();
        Optional<Category> cat = categoryService.getCategoryById(product.getCategory().getId());
        Category category = new Category(cat.get().getId(), cat.get().getName());
        product.setCategory(category);

        Logger logger = Logger.getLogger(
                ProductController.class.getName());
        logger.info(product.toString());

        Long key = new Date().getTime();

        if (result.hasErrors()) {
            return validation(result);
        }

        makeDirectoryIfNotExist(imageDirectory);

        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(productService.save(product));
        } catch (Exception ex) {
            if (ex.getMessage().contains("Duplicate")) {
                return new ResponseEntity<>(ex.getMessage(), HttpStatus.FORBIDDEN);
            } else
                return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }

    }

    ///////////////////////////////////////////////////////

    private void makeDirectoryIfNotExist(String imageDirectory) {
        File directory = new File(imageDirectory);
        if (!directory.exists()) {
            directory.mkdir();
        }
    }

    // @GetMapping("/images/{id}")
    // public ResponseEntity<?> seePhoto(@PathVariable Long id) {
    // Optional<Product> p = productService.findById(id);

    // if (p.isEmpty() || p.get().getImage() == null) {
    // return ResponseEntity.notFound().build();
    // }

    // Resource image = new ByteArrayResource(p.get().getImage());

    // return ResponseEntity.ok()
    // .contentType(MediaType.IMAGE_JPEG)
    // .body(image);
    // }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@Valid @RequestBody Product product,
            BindingResult result) {

        if (result.hasErrors()) {
            return validation(result);
        }

        Optional<Product> p = productService.update(product, product.getId());

        if (p.isPresent()) {
            try {
                return ResponseEntity.status(HttpStatus.CREATED).body(p.orElseThrow());
            } catch (Exception ex) {
                if (ex.getMessage().contains("Duplicate")) {
                    return new ResponseEntity<>(ex.getMessage(), HttpStatus.FORBIDDEN);
                } else
                    return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
            }
        }

        return ResponseEntity.notFound().build();
    }

    // @PutMapping("/{id}")
    // public ResponseEntity<?> update(@Valid @RequestBody Product product,
    // BindingResult result, @PathVariable Long id) {
    // if (result.hasErrors()) {
    // return validation(result);
    // }
    // Optional<Product> p = productService.update(product, id);
    // if (p.isPresent()) {
    // return ResponseEntity.status(HttpStatus.CREATED).body(p.orElseThrow());
    // }
    // return ResponseEntity.notFound().build();
    // }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> remove(@PathVariable Long id) {
        Optional<Product> p = productService.findById(id);
        if (p.isPresent()) {
            productService.remove(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    private ResponseEntity<?> validation(BindingResult result) {
        Map<String, String> errors = new HashMap<>();

        result.getFieldErrors()
                .forEach(err -> {
                    errors.put(err.getField(),
                            err.getDefaultMessage());
                });

        return ResponseEntity.badRequest().body(errors);
    }
}
