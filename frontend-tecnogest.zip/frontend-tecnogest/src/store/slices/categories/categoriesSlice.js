import { createSlice } from "@reduxjs/toolkit";

export const initialCategoryForm = {
    id: 0,
    name: '',
}

const initialErrors = {
    name: '',
};

export const categoriesSlice = createSlice({

    name: 'categories',
    initialState: {
        categories: [],
        paginator: {},
        categorySelected: initialCategoryForm,
        errors: initialErrors,
    },
    reducers: {
        loadingCategories: (state, action) => {
            state.categories = action.payload.content;
            state.paginator = action.payload;
        },
        loadingError: (state, action) => {
            state.errors = action.payload;
        },
    },

});

export const {
    loadingCategories,
    loadingError,
} = categoriesSlice.actions