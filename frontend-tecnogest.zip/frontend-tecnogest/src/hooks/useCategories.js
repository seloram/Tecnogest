import { useDispatch, useSelector } from "react-redux";
import { findCategoriesPages } from "../services/categoryService";
import {loadingCategories, initialCategoryForm, loadingError } from "../store/slices/categories/categoriesSlice";
import { useAuth } from "../auth/hooks/useAuth";


export const useCategories = () => {

    const { categories, errors, paginator } = useSelector(state => state.categories);
    const dispatch = useDispatch();
    const { login, handlerLogout } = useAuth();

    const getCategories = async (page = 0) => {

        try {
            const result = await findCategoriesPages(page);
            dispatch(loadingCategories(result.data));
        } catch (error) {
            if (error.response?.status == 401) {
                handlerLogout();
            }
        }
        
    }

    return {
        categories,
        errors,
        paginator,
        initialCategoryForm,
        getCategories
    }


}