import { useEffect, useState } from "react";
import { useItemsCart } from "../hooks/useItemsCart";
import { NavLink, useParams } from "react-router-dom";
import { useProducts } from "../hooks/useProducts";
import { CardActionArea, CardMedia } from "@mui/material";

export const ProductCard = ({ handler, id, productName, description, image, price, category }) => {

    const onAddProduct = (product) => {
        handler(product);
    }

    const { handlerRemoveProduct } = useProducts();   
   
    return (
        <div className="col-4 my-2">
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title">{productName} </h5>
                    <p className="card-text">{description} </p>
                    <p className="card-text">{price} </p>
                    <p className="card-text">{category} </p>

                    <img
                        alt="not found"
                        className="img-fluid"
                        width={"250px"}
                        // src={"http://localhost:8080/products/images/" + id}
                        src={image}
                    />
                    
                    <button
                        className="btn btn-primary"
                        onClick={() => onAddProduct({ id, productName, description, image, price })}
                    >
                        Add to cart
                    </button>
                    <div>
                        <NavLink
                            className={'btn btn-secondary btn-sm'}
                            to={'/products/update/' + id}
                        >
                            details
                        </NavLink>
                        <button
                            type="button"
                            className="btn btn-danger btn-sm"
                            onClick={() => handlerRemoveProduct(id)}
                        >
                            remove
                        </button>
                    </div>
                    {/* <CardActionArea>
                        <CardMedia
                            component="img" image={image} />
                    </CardActionArea> */}
                </div>
            </div>
        </div>
    )
}