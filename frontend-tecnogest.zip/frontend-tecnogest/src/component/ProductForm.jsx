import React, { useEffect, useState } from "react";
import { useProducts } from "../hooks/useProducts";
import { Button, FormControl, InputLabel, MenuItem, Select, TextField } from "@mui/material";

import { useCategories } from "../hooks/useCategories";
import { Form, Navigate } from "react-router-dom";
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";
import {
    MDBBtn, MDBDropdown, MDBDropdownItem,
    MDBDropdownMenu, MDBDropdownToggle, MDBInput,
    MDBTextArea, MDBValidation, MDBValidationItem
} from "mdb-react-ui-kit";
import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";

import { eraseErrors } from "../store/slices/products/productsSlice";

export const ProductForm = ({ categories, productSelected }) => {
    const { initialProductForm, handlerAddProduct, eraseErrors,
        handlerCloseForm, restart, clearForm } = useProducts();
    const [productForm, setProductForm] = useState(initialProductForm);
    console.log("entrando en formulario...." + window.location.href);
    const { errors } = useSelector(state => state.products);
    if (errors.productname) {
        Swal.fire({
            title: 'Product already exits!!!',
            confirmButtonText: 'Ok',
            text: errors.productname
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {

                setProductForm(initialProductForm);
                dispatch(eraseErrors());
            }
        })
    }
    if (errors.imageSize) {
        Swal.fire({
            title: 'Data too big',
            confirmButtonText: 'Ok',
            text: errors.imageSize
        }).then((result) => {
            if (result.isConfirmed) {
                setProductForm(initialProductForm);
                dispatch(eraseErrors());
            }
            /* Read more about isConfirmed, isDenied below */
            // if (result.isConfirmed) {
            //     dispatch(restart(productSelected, errors));
            // }
        })

    }

    const dispatch = useDispatch();
    useEffect(() => {
        // const validateRef = validate.current;
        let bytesImage = null;
        const validate = document.querySelectorAll('.needs-validation');
        Array.prototype.slice.call(validate)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    } else {
                    }
                    form.classList.add('was-validated')
                }, false)
            })
    }, []);
    const [priceErrors, setPriceErrors] = useState('');
    //let myRef = React.createRef();


    const [open, setOpen] = useState(false);
    const handleOpen = () => {
        setOpen(!open);
    };
    const formData = new FormData();

    const { id, productName, description, image, price, category } = productForm;
    const [selectedImage, setSelectedImage] = useState("");
    /* start */
    const stateImage = {
        image: null,
        base64URL: ""
    };
    const [state, setState] = useState(stateImage);
    const getBase64 = image => {
        return new Promise(resolve => {
            let fileInfo;
            let baseURL = "";
            // Make new FileReader
            let reader = new FileReader();
            // Convert the file to base64 text
            reader.readAsDataURL(image);
            // on reader load something...
            reader.onload = () => {
                // Make a fileInfo Object
                baseURL = reader.result;
                resolve(baseURL);
            };
        });
    };
    const handleFileInputChange = async e => {

        let { image } = state;
        image = e.target.files[0];
        getBase64(image)
            .then(result => {
                image["base64"] = result;

                setState({
                    base64URL: result,
                    image
                });
            })
            .catch(err => {

            });

        setState({
            image: e.target.files[0]
        });
        setImagePreview(e.target.files[0]);
        const buffer = await image.arrayBuffer();
        // each entry of array should contain 8 bits
        const bytes = new Uint8Array(buffer);

    };
    /* end */
    useEffect(() => {
        setProductForm({
            ...productSelected,
        });
    }, [productSelected]);

    useEffect(() => {
        setProductForm(initialProductForm)
    }, [window.location.href])

    let typeForm = '';
    if (id == 0)
        typeForm = 'new'
    else
        typeForm = 'update'

    const onInputChange = ({ target }) => {
        const { name, value } = target;
        setProductForm({
            ...productForm,
            [name]: value,
        })

        if (name == 'price' && value <= 0) {
            setPriceErrors('menor que 1');
        }
        if (name == 'price' && value >= 1000000) {
            setPriceErrors('you sure this is ok???');
        }
    }

    const handleSubmit = async (event) => {
        'use strict'
        event.preventDefault();
        // var forms = document.querySelectorAll('.needs-validation');
        // Array.prototype.slice.call(forms)
        //     .forEach(function (form) {
        //         form.addEventListener('submit', function (event) {
        //             if (!form.checkValidity()) {
        //                 event.preventDefault()
        //                 event.stopPropagation()
        //             } else {
        //             }
        //             form.classList.add('was-validated')
        //         }, false)
        //     })
        productForm.image = state.base64URL;
        imageData.append('productName', productName);
        imageData.append('description', description);
        imageData.append('price', price);
        imageData.append('id', id);
        // imageData.append('category', JSON.stringify(category));
        if (category.id == undefined) {
            imageData.append('idCategory', category);
        } else
            imageData.append('idCategory', category);
        imageData.append('name', category.name);
        if (imagePreview == "")
            imageData.append('imageFile', null);

        // productForm.image=state.base64URL;
        await handlerAddProduct(productForm, typeForm);
        const validate = document.querySelector('.needs-validation');
        validate.classList.remove('was-validated');
        validate.classList.add('needs-validation');
        document.getElementById('validationCustom04').innerHTML = "";
        setImagePreview("");
        setProductForm(initialProductForm);

    }
    /* -------------------------------------------------------------------------------------- */
    const [imagePreview, setImagePreview] = useState("");
    const [imageData, setImageData] = useState(new FormData());
    const [imageName, setImageName] = useState("");
    // const handleUploadClick = event => {
    //     let file = event.target.files[0];
    //     setImagePreview(event.target.files[0]);
    //     image = event.target.value;
    //     imageData.append('imageFile', file);
    //     setImageData(imageData);
    // };
    const uploadImageWithAdditionalData = () => {
        dispatch(uploadImage(imageData));
    };
    const handleChange = event => {
        setImageName(event.target.value)
    };
    const handleClick = () => {
        myRef.current.value = "your clicked here"
    };
    /* -------------------------------------------------------------------------------------- */
    return (
        <>
            <form className="row g-3 needs-validation" noValidate onSubmit={handleSubmit}>
                <div className="col-md-4 position-relative">
                    <label htmlFor="validationCustom01" className="form-label">Name</label>
                    <input type="text"
                        className="form-control"
                        id="validationCustom01"
                        name="productName"
                        value={productName}
                        placeholder="Name"
                        onChange={onInputChange}
                        required />
                    <div className="invalid-tooltip">
                        "Introduce the name!"
                    </div>
                </div>
                <div className="col-md-4 position-relative">
                    <label htmlFor="validationCustom02" className="form-label">Price</label>
                    <input
                        type="number"
                        className="form-control"
                        id="validationCustom02"
                        name="price"
                        min={1}
                        max={100}
                        required
                        placeholder="Price"
                        onChange={onInputChange}
                        value={price}
                    />
                    <div className="invalid-tooltip">
                        {priceErrors || 'Introduce a price!!!'}
                    </div>
                </div>
                <div className="col-mod-6 position-relative">
                    <label htmlFor="validationTextarea" className="form-label">Description</label>
                    <textarea className="form-control"
                        id="validationTextarea"
                        placeholder="Description"
                        name="description"
                        onChange={onInputChange}
                        value={description}
                        required />
                    <div className="invalid-tooltip">
                        Please enter a message a description!.
                    </div>
                </div>

                {category.id != 0 && typeForm == 'update' ? <div mb-4>{category.name}</div> : null}
                <div className="col-md-3 position-relative">
                    {/*   <label htmlFor="validationCustom04" className="form-label">Category</label> */}
                    <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label"> Select a Category</InputLabel>
                        <Select className="form-select mt-4"
                            id="validationCustom04"
                            name="category"
                            onChange={onInputChange}
                            required={typeForm == 'new' ? true : false}
                        >
                            {categories.map(cat => (
                                <MenuItem key={cat.id} value={cat}>{cat.name}</MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <div className="invalid-tooltip">
                        Please select a category.
                    </div>

                </div>
                <div className="col-md-4 position-relative">
                    <input type="text"
                        className="form-control"
                        id="validationCustom011"
                        hidden
                        value={category.name ? category.name : ''}
                        onChange={onInputChange}
                        required />
                    <div className="invalid-tooltip">
                        Introduce the category!
                    </div>
                </div>
                <div className="col-md-3 position-relative">
                    <img
                        className="img-fluid"
                        alt={"not found"}
                        name="image"
                        width={"250px"}
                        // src={imagePreview ? state.base64URL : "http://localhost:8080/products/images/" + id}
                        src={imagePreview ? state.base64URL : productForm.image}
                    />
                </div>
                <div className="col-md-12 position-relative mb-5">
                    <input
                        accept="image/*"
                        id="upload-profile-image"
                        type="file"
                        required={typeForm == 'new' ? true : false}
                        // onChange={handleUploadClick}
                        onChange={handleFileInputChange}
                    />
                    <div className="invalid-tooltip">
                        Enter a photo!
                    </div>
                    <label htmlFor="upload-profile-image">
                        <Button type="submit"
                            variant="contained"
                            color="primary"
                            component="span"
                        >
                            Change Image
                        </Button>
                    </label>
                </div>
                <div className="col-12 mt-4">
                    <button type="submit" className="btn btn-primary"
                    > {id > 0 ? 'Update' : 'Create'}
                    </button>
                </div>
            </form>
        </>
    )
}

