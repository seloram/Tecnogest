import usersApi from "../apis/usersApi";

const BASE_URL = '';

export const findAllPagesProducts = async (page = 0) => {

    try {
        const response = await usersApi.get(`${BASE_URL}/products/page/${page}`);
        return response;
    } catch (error) {
        throw error;
    }
}

export const save = async (imageData) => {

    try {
        // return await usersApi.post(`${BASE_URL}/products/addProduct`, imageData,{
        //     'Content-Type':'multipart/form-data', 'Accept':'*/*'});
        return await usersApi.post(`${BASE_URL}/products/addProduct`, imageData);
    } catch (error) {
        throw error;
    }
}

export const update = async (product) => {

    try {
        return await usersApi.put(`${BASE_URL}/products/${product.id}`, product, {
            'Content-Type':'multipart/form-data', 'Accept':'*/*'});
    } catch (error) {
        throw error;
    }
}

export const remove = async (id) => {

    try {
        await usersApi.delete(`${BASE_URL}/products/${id}`);
    } catch (error) {
        throw error;
    }
}

export const calculateTotal = (items) => {

    return items.reduce(
        (accumulator, item) => accumulator + item.product.price * item.quantity, 0);
}

export const totalItems = (items) => {

    return items.reduce((accumulator, item) => accumulator + item.quantity, 0);
}