import { useDispatch, useSelector } from "react-redux"
import { findAll } from "../services/userService";
import { findAllRoles } from "../services/roleService";
import { loadingRoles } from "../store/slices/roles/roleSlice";
import { useAuth } from "../auth/hooks/useAuth";

export const useRoles = () => {
    const { roles, errors } = useSelector(state => state.roles);
    const dispatch = useDispatch();
    const { login, handlerLogout } = useAuth();
    const getRoles = async () => {
        try {
            const result = await findAllRoles();
            dispatch(loadingRoles(result.data));
        } catch (error) {
            if (error.response?.status == 401) {
                handlerLogout();
            }
        }
    }

    return {
        roles,
        errors,
        getRoles
    }
}