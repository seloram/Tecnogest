import { LoginPage } from "./auth/pages/LoginPage";
import { Navigate, Route, Routes } from "react-router-dom";
import { UserRoutes } from "./routes/UserRoutes";
import { useAuth } from "./auth/hooks/useAuth";
import { useSelector } from "react-redux";
import { ProductRoutes } from "./routes/ProductRoutes";
import { ProductsPage } from "./pages/ProductsPage";
import { useItemsCart } from "./hooks/useItemsCart";

export const AppRoutes = () => {

    const { isAuth, isLoginLoading } = useSelector(state => state.auth);
    //   const { cartItems, handlerAddProductCart, handlerDeleteProductCart } = useItemsCart();
    if (isLoginLoading) {
        return (
            <div className="container my-4">
                <div className="spinner-border text-warning" role="status">
                    <span className="visually-hidden">
                        Loading...
                    </span>
                </div>
            </div>
        )
    }

    return (
        <Routes>
            <Route path='/products/*' element={<ProductRoutes />} />
            {isAuth
                ?
                <>
                    <Route path='/users/*' element={<UserRoutes />} />
                    <Route path='/' element={<Navigate to="/products" />} />
                </> :
                <>
                    <Route path="/products/addProduct" element={<Navigate to="/login" />} />
                    <Route path="/products/update/*" element={<Navigate to="/login" />} />                    
                    <Route path="/login" element={<LoginPage />} />
                    <Route path='/' element={<Navigate to="/products" />} />
                    <Route path="/users" element={<Navigate to="/login" />} />
                </>
            }

        </Routes>
    );
}