import { Navbar } from "react-bootstrap";
import { Route } from "react-router-dom";


export const RoleRoutes = () => {

    const { isAdmin } = useSelector(state => state.auth);

    return (
        <>
       
        </>
    )
}