import { useEffect } from "react";
import { UserModalForm } from "../component/UserModalForm";
import { UsersList } from "../component/UsersList";
import { useUsers } from "../hooks/useUsers";
import { useAuth } from "../auth/hooks/useAuth";
import { NavLink, useParams } from "react-router-dom";
import { Paginator } from "../component/Paginator";


export const UsersPage = () => {

    const { page } = useParams();

    const {
        users,
        visibleForm,
        paginator,
        handlerOpenForm,
        getUsers,
    } = useUsers();

    const { login } = useAuth();

    useEffect(() => {
        getUsers(page);
    }, [, page]);

    return (
        <>
            {!visibleForm ||
                <UserModalForm />
            }
            <div className="container my-4">
                <div className="row">
                    <div className="col">
                        {users.length === 0 ?
                            <div className="alert alert-warning">
                                There are no users
                            </div>
                            :
                            <>
                                <UsersList />
                                <Paginator url="/users/page" paginator={paginator} />
                            </>
                        }
                        {
                            (visibleForm || !login.isAdmin) || //<button
                                //className="btn btn-primary my-2"
                                //onClick={handlerOpenForm}
                           // >
                                <NavLink 
                                    className="btn btn-primary "
                                    to="/users/register"
                                >
                                    <b>Register</b>
                                </NavLink>
                             //   New User
                         //   </button>
                        }
                    </div>
                </div>
            </div>
        </>
    );

}