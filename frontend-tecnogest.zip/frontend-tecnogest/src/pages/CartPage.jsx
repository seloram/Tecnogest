import { CartView } from "../component/CartView";
import { useItemsCart } from "../hooks/useItemsCart";

export const CartPage = ({cartItems, handlerDeleteProductCart}) => {
  //  const {  handlerDeleteProductCart } = useItemsCart();

    return (
        <>
            <div className="container m-y4">
                <div className="row">
                    <div className="col">
                        <>
                            {cartItems?.length <= 0 ||
                                <div className="my-4 w-50">
                                    <CartView
                                        handlerDelete={handlerDeleteProductCart}
                                        items={cartItems}
                                    />
                                </div>
                            }
                        </>
                    </div>
                </div>
            </div>
        </>
    )
}