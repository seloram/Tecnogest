package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Category;
import com.sergio.backend.tecnogest.backendtecnogest.repositories.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService{

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    @Transactional(readOnly = true)
    public String getNameByProductId(Long id){
        String nameCategory = categoryRepository.getNameByProductId(id);
        return nameCategory;
    }

    @Override
    public List<Category> findCategories() {
        List<Category> categories = (List<Category>) categoryRepository.findAll();
        return categories;
    }

    @Override
    public Page<Category> findCategoriesPage(Pageable pageable) {
        Page<Category> categoriesPage = categoryRepository.findAll(pageable);
        return categoriesPage;
    }

    @Override
    public Optional<Category> getCategoryById(Long id) {
        Optional<Category> c =  categoryRepository.findById(id);
       
        if(c.isPresent()){
            return c;
        }
        return Optional.empty();
        
    }

    
    
}
