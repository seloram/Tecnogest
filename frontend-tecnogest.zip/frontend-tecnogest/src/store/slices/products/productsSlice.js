import { createSlice } from "@reduxjs/toolkit";

export const initialProductForm = {
    id: 0,
    productName: '',
    description: '',
    category: { id: 0, name: '' },
    image: '',
    price: '',
}

const initialErrors = {
    productName: '',
    description: '',
    image: '',
    price: '',
    error: false,
};

export const productsSlice = createSlice({

    name: 'products',
    initialState: {
        products: [],
        paginator: {},
        productSelected: initialProductForm,
        errors: initialErrors,
    },
    reducers: {
        addProduct: (state, action) => {
            state.products = [
                ...state.products,
                {
                    ...action.payload,
                    image: action.payload.imageHashCode
                }
            ];
            state.productSelected = initialProductForm;
        },
        removeProduct: (state, action) => {
            state.products = state.products.filter(product => product.id !== action.payload);
        },
        updateProduct: (state, action) => {
            state.products = state.products.map(p => {
                if (p.id === action.payload.id) {
                    console.log(action.payload.imageHashCode)
                    return {
                        ...action.payload,
                        image: action.payload.imageHashCode
                    };
                }
                return p;
            });
            state.productSelected = initialProductForm;
        },
        loadingProducts: (state, { payload }) => {
            state.products = payload.content;
            state.paginator = payload;
        },
        loadingError: (state, action) => {
            state.errors = action.payload;
            state.errors.error = true;
        },
        eraseErrors: (state, action) => {
            state.errors = initialErrors;
        },
        clearForm: (state, action) => {
            state.productSelected = initialProductForm;
        }
    }
});

export const {
    addProduct,
    removeProduct,
    updateProduct,
    loadingProducts,
    loadingError,
    eraseErrors,
    clearForm,
    productSelected
} = productsSlice.actions