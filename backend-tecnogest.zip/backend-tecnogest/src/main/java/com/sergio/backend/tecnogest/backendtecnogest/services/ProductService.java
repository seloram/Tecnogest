package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Product;

public interface ProductService {

    List<Product> findProducts();

    Page<Product> findAll(Pageable pageable);

    Optional<Product> findById(Long id);

    Product save(Product product);

    Optional<Product> update (Product product, Long id);

    void remove(Long id);
}
