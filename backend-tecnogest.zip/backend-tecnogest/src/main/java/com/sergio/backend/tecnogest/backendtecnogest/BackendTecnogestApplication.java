package com.sergio.backend.tecnogest.backendtecnogest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTecnogestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTecnogestApplication.class, args);
	}

}
