package com.sergio.backend.tecnogest.backendtecnogest.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Category;

public interface CategoryRepository extends CrudRepository<Category, Long>{

   @Query("select p.name from Category p where p.id=?1")
   String getNameByProductId(Long id);

   Page<Category> findAll(Pageable pageable);
    
}
