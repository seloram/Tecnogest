package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sergio.backend.tecnogest.backendtecnogest.models.dto.UserDto;
import com.sergio.backend.tecnogest.backendtecnogest.models.dto.mapper.DtoMapperUser;
import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Role;
import com.sergio.backend.tecnogest.backendtecnogest.models.entities.User;
import com.sergio.backend.tecnogest.backendtecnogest.models.request.UserRequest;
import com.sergio.backend.tecnogest.backendtecnogest.repositories.RoleRepository;
import com.sergio.backend.tecnogest.backendtecnogest.repositories.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> findAll() {
        List<User> users = (List<User>) repository.findAll();

        return users
                .stream()
                .map(u -> DtoMapperUser
                        .builder()
                        .setUser(u)
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<UserDto> findById(Long id) {
        Optional<User> o = repository.findById(id);
        if (o.isPresent()) {
            return Optional.of(
                    DtoMapperUser
                            .builder()
                            .setUser(o.orElseThrow())
                            .build());
        }
        return Optional.empty();
    }

    @Override
    @Transactional
    public User save(User user) {
        String passwordBc = passwordEncoder.encode(user.getPassword());
        user.setPassword(passwordBc);
        return repository.save(user);
    }

    @Override
    @Transactional
    public Optional<UserDto> update(UserRequest user, Long id) {
        Optional<User> o = repository.findById(id);
        User userOptional = null;
        if (o.isPresent()) {
            User userDb = o.orElseThrow();
            userDb.setRoles(user.getRoles());
            userDb.setUsername(user.getUsername());
            userDb.setEmail(user.getEmail());
            userOptional = repository.save(userDb);
        }
        return Optional.ofNullable(DtoMapperUser.builder().setUser(userOptional).build());
    }

    @Override
    @Transactional
    public void remove(Long id) {
        repository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserDto> findAll(Pageable pageable) {
        Page<User> usersPage = repository.findAll(pageable);
        return usersPage.map(u -> DtoMapperUser.builder().setUser(u).build());
    }

}
