import { useState } from "react";
import { useProducts } from "../hooks/useProducts"
import { CartView } from "./CartView";
import { ProductCard } from "./ProductCard";


export const ProductsList = ({ handler}) => {

    const { products } = useProducts();
    return (
        <>
            <div className="container">
                <p>Product's List</p>
                <div className="row">
                    {products.map(({ id, productName, description, price, image, category }) =>
                        <ProductCard
                            handler={handler}
                            key={id}
                            id={id}
                            category={category.name}
                            productName={productName}
                            description={description}
                            image={image}
                            price={price} />
                    )}
                </div>
            </div>

        </>
    )
}