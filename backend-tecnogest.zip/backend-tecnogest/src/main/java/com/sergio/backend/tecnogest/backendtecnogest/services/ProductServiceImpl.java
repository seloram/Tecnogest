package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Product;
import com.sergio.backend.tecnogest.backendtecnogest.repositories.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Product> findProducts() {
        List<Product> products = (List<Product>) productRepository.findAll();
        return products;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Product> findById(Long id) {
        Optional<Product> p = productRepository.findById(id);
        if (p.isPresent()) {
            return p;
        }
        return Optional.empty();
    }

    @Override
    @Transactional(readOnly = true)
    public Page<Product> findAll(Pageable pageable) {
        Page<Product> productsPage = productRepository.findAll(pageable);
        return productsPage;
    }

    @Override
    public Product save(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Optional<Product> update(Product product, Long id) {
        Optional<Product> p = productRepository.findById(id);
        Product productOptional = null;
        if (p.isPresent()) {
            Product productDb = p.orElseThrow();
            productDb.setDescription(product.getDescription());
            productDb.setProductName(product.getProductName());
            if (product.getCategory() != null) {
                productDb.setCategory(product.getCategory());
            }
            productDb.setPrice(product.getPrice());
            if (product.getImage() != "") {
                productDb.setImage(product.getImage());
            }
            productOptional = productRepository.save(productDb);
        }
        return Optional.ofNullable(productOptional);
    }

    @Override
    @Transactional
    public void remove(Long id) {
        productRepository.deleteById(id);
    }

}
