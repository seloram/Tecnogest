import usersApi from "../apis/usersApi";

const BASE_URL = '';

export const findCategoriesPages = async (page = 0) => {

    try {
        const response = await usersApi.get(`${BASE_URL}/categories/page/${page}`);
        return response;
    } catch (error) {
        throw error;
    }

}