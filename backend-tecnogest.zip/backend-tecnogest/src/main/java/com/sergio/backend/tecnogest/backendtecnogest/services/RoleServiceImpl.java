package com.sergio.backend.tecnogest.backendtecnogest.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sergio.backend.tecnogest.backendtecnogest.models.entities.Role;
import com.sergio.backend.tecnogest.backendtecnogest.repositories.RoleRepository;

@Service
public class RoleServiceImpl implements RoleService{
    
    @Autowired
    private RoleRepository roleRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Role> findRoles() {
        List<Role> roles = (List<Role>) roleRepository.findAll();
        return roles;
    }

    @Override
    public Role save(Role role) {
        return roleRepository.save(role);
    }

    @Override
    public void remove(Long id) {
        roleRepository.deleteById(id);
    }

    @Override
    public Optional<Role> findById(Long id) {
        Optional<Role> r = roleRepository.findById(id);
        if(r.isPresent()){
            return r;
        }

        return Optional.empty();
    }

    

}
