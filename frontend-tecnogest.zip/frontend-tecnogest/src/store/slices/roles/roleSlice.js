import { createSlice } from "@reduxjs/toolkit"

export const initialRoles = {
    id: 0,
    name: ''
}

export const initialErrors = {
    name: ''
}

export const roleSlice = createSlice({
    name: 'roles',
    initialState: {
        roles: [],
        errors: initialErrors
    },
    reducers: {
        addRole: (state, action) => {
            state.roles = [
                ...state.roles,
                {
                    ...action.payload
                }
            ];

        },
        removeRole: (state, action) => {
            state.roles = state.roles.filter(role => role.id !== action.payload);
        },
        loadingRoles: (state, action) => {
            state.roles = action.payload;
        },
        loadingError: (state, action) => {
            state.errors = action.payload
        },
        eraseErrors: (state, action) => {
            state.errors = initialErrors
        }
    }
})

export const {
    addRole,
    removeRole,
    loadingRoles,
    loadingError,
    eraseErrors
} = roleSlice.actions