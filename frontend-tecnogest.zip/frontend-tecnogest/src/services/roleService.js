import usersApi from "../apis/usersApi";

const BASE_URL = '';

export const findAllRoles = async () => {
    try {
        const response = await usersApi.get(`${BASE_URL}/roles`);
        return response;
    } catch (error) {
        throw error;
    }
}

export const saveRole = async (role) => {

    try {
        return await usersApi.post(`${BASE_URL}/roles`, role);
    } catch (error) {
        throw error;
    }
}

export const removeRole = async (id) => {
    try {
        await usersApi.delete(`${BASE_URL}/role/${id}`);
    } catch (error) {
        throw error;
    }
}