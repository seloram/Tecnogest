import { Navigate, Route, Routes } from "react-router-dom"
import { UsersPage } from "../pages/UsersPage"
import { Navbar } from "../component/layout/Navbar"
import { RegisterPage } from "../pages/RegisterPage"
import { useContext, useEffect } from "react"
import { useAuth } from "../auth/hooks/useAuth"
import { useSelector } from "react-redux"
import { ProductsPage } from "../pages/ProductsPage"
import { CartPage } from "../pages/CartPage"
import { ProductRoutes } from "./ProductRoutes"
import { useRoles } from "../hooks/useRoles"
import { useUsers } from "../hooks/useUsers"

export const UserRoutes = () => {
    const { isAdmin } = useSelector(state => state.auth);
    
    const {errors } = useSelector(state=>state.users);
    const { roles, getRoles } = useRoles();
    useEffect(() => {
        getRoles();
    },[]);
    return (

        <>
            <Navbar />
            <Routes>
                <Route path="/" element={<UsersPage />} />  
                <Route path="/page/:page" element={<UsersPage />} />   

                {!isAdmin ||
                    <>
                        <Route path="/register" element={<RegisterPage errorsUser={errors} rolesDB={roles} />} />
                        <Route path="/update/:id" element={<RegisterPage rolesDB={roles} />} />
                    </>
                }
                <Route path="/" element={<Navigate to="/users" />} />
   
            </Routes>
        </>
    )
}